﻿<#
.SYNOPSIS
  Remove o Diagnóstico 2.0 deste PC.

.DESCRIPTION
      powershell -ExecutionPolicy Bypass -File .\Desinstalar.ps1

  Encerra o aplicativo, remove os arquivos, o atalho do Menu Iniciar e o "iniciar com o Windows". A configuração e os
  logs ficam em C:\ProgramData\Bionexo\Diagnostico2 (use -ApagarDados para remover). A tabela elber_telemetry do banco
  NUNCA é alterada: os dados já coletados continuam lá.

.PARAMETER Dir
  Pasta onde foi instalado. Padrão: C:\Program Files\Bionexo\Diagnostico2.

.PARAMETER ApagarDados
  Remove também a configuração e os logs.
#>
param(
    [string]$Dir = (Join-Path $env:ProgramFiles 'Bionexo\Diagnostico2'),
    [switch]$ApagarDados
)
$ErrorActionPreference = 'Stop'
$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $PSBoundParameters.ContainsKey('Dir') -and -not $ehAdmin) {
    throw 'Abra o PowerShell como Administrador, ou use -Dir <pasta> se instalou em outro lugar.'
}

Get-Process -Name Diagnostico2 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.Id -Force; $_.WaitForExit(5000) | Out-Null }
Write-Host 'Aplicativo encerrado.'

# "iniciar com o Windows" (um atalho por usuário) e Menu Iniciar
$nome = 'Diagnostico 2.0.lnk'
$alvos = @((Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup\$nome"),
           (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\$nome"))
if ($ehAdmin) {
    $alvos += Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\$nome"
    $alvos += Get-ChildItem 'C:\Users' -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        Join-Path $_.FullName "AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\$nome"
    }
}
foreach ($a in $alvos) { if (Test-Path $a) { Remove-Item $a -Force; Write-Host "  removido: $a" } }

if (Test-Path $Dir) { Remove-Item $Dir -Recurse -Force; Write-Host "Arquivos removidos: $Dir" }
else { Write-Host "Pasta não encontrada (já removida?): $Dir" }

$dados = Join-Path $env:ProgramData 'Bionexo\Diagnostico2'
if ($ApagarDados) {
    if (Test-Path $dados) { Remove-Item $dados -Recurse -Force; Write-Host "Configuração e logs removidos: $dados" }
}
else { Write-Host "Configuração e logs mantidos em $dados (use -ApagarDados para remover)." }
Write-Host 'A tabela elber_telemetry do banco não foi alterada. Pronto.'
