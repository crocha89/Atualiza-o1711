﻿<#
.SYNOPSIS
  Instala o Diagnóstico 2.0 neste PC (um único aplicativo: bandeja + agente de telemetria + janela do diagnóstico).

.DESCRIPTION
  Rode em um PowerShell como Administrador, dentro da pasta do pacote:

      powershell -ExecutionPolicy Bypass -File .\Instalar.ps1

  Copia o aplicativo para Program Files, libera a pasta de dados, cria o atalho no Menu Iniciar, confere o ambiente do V5
  e abre o aplicativo. No primeiro uso ele liga sozinho o "iniciar com o Windows" (dá para desligar na aba TELEMETRIA).

  Para só testar, sem instalar: dê dois cliques em Diagnostico2.exe.

.PARAMETER Dir
  Pasta de destino. Padrão: C:\Program Files\Bionexo\Diagnostico2. Informando outra pasta, não exige Administrador.

.PARAMETER NaoIniciar
  Não abre o aplicativo ao final.
#>
param(
    [string]$Dir = (Join-Path $env:ProgramFiles 'Bionexo\Diagnostico2'),
    [switch]$NaoIniciar
)
$ErrorActionPreference = 'Stop'

$origem  = $PSScriptRoot
$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $PSBoundParameters.ContainsKey('Dir') -and -not $ehAdmin) {
    throw 'Abra o PowerShell como Administrador (o destino padrão é o Program Files), ou use -Dir <pasta> para instalar em outro lugar.'
}
if (-not (Test-Path (Join-Path $origem 'Diagnostico2.exe'))) { throw 'Diagnostico2.exe não encontrado ao lado deste script.' }

Write-Host "Instalando o Diagnóstico 2.0 em: $Dir"

# 1) encerra uma instância em execução (os dados já gravados ficam no banco)
Get-Process -Name Diagnostico2 -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host '  encerrando a instância em execução...'
    Stop-Process -Id $_.Id -Force
    $_.WaitForExit(5000) | Out-Null
}

# 2) copia os arquivos
if ((Resolve-Path $origem).Path.TrimEnd('\') -ne ([IO.Path]::GetFullPath($Dir)).TrimEnd('\')) {
    New-Item -ItemType Directory -Force $Dir | Out-Null
    Get-ChildItem $origem -Force | Where-Object { $_.Name -notin 'Instalar.ps1', 'Desinstalar.ps1', 'LEIA-ME.txt' } |
        Copy-Item -Destination $Dir -Recurse -Force
}
$exe = Join-Path $Dir 'Diagnostico2.exe'
if (-not (Test-Path $exe)) { throw "Falha ao copiar: $exe não existe." }
Write-Host '  arquivos copiados.'

# 3) pasta de dados (configuração, status e logs): o aplicativo roda com o usuário do Windows e precisa gravar nela
$dados = Join-Path $env:ProgramData 'Bionexo\Diagnostico2'
New-Item -ItemType Directory -Force $dados | Out-Null
if ($ehAdmin) { & icacls.exe $dados /grant '*S-1-5-32-545:(OI)(CI)M' /T /Q | Out-Null }
Write-Host "  dados em: $dados"

# 4) atalho no Menu Iniciar
$menu = if ($ehAdmin) { Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs' } else { Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs' }
$atalho = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $menu 'Diagnostico 2.0.lnk'))
$atalho.TargetPath = $exe
$atalho.WorkingDirectory = $Dir
$atalho.Description = 'Diagnóstico 2.0 - telemetria da placa Elber-Icaru'
$atalho.Save()
Write-Host '  atalho criado no Menu Iniciar.'

# 5) confere o ambiente do V5 (só avisa; o aplicativo tenta de novo sozinho)
Write-Host ''
Write-Host 'Conferindo o ambiente do V5:'
$pasta = 'C:\Gtt Healthcare\GTCabinet Settings\App'
$xmls = @(Get-ChildItem $pasta -Filter *.xml -ErrorAction SilentlyContinue | Where-Object { (Get-Content $_.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -match '<CabinetSettings' })
if     ($xmls.Count -eq 1) { Write-Host "  [ok] configuração do V5: $($xmls[0].Name)" }
elseif ($xmls.Count -eq 0) { Write-Host "  [!] nenhum XML do V5 (CabinetSettings) em $pasta" }
else                       { Write-Host "  [!] mais de um XML do V5 em $pasta - o aplicativo não escolhe sozinho" }

$svc = Get-Service -Name PythonSerialServerLoader -ErrorAction SilentlyContinue
if     (-not $svc)                    { Write-Host '  [!] serviço PythonSerialServerLoader não encontrado' }
elseif ($svc.Status -eq 'Running')    { Write-Host '  [ok] serviço PythonSerialServerLoader em execução' }
else                                  { Write-Host "  [!] serviço PythonSerialServerLoader está $($svc.Status)" }

$porta = $false
try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', 61900); $porta = $c.Connected; $c.Close() } catch { }
if ($porta) { Write-Host '  [ok] Serial Server escutando em localhost:61900' }
else        { Write-Host '  [!] nada escutando em localhost:61900 (o aplicativo reconecta quando o Serial Server subir)' }

# 6) abre o aplicativo pelo explorer.exe, que o inicia sem elevação, na sessão do usuário (a bandeja precisa disso)
if (-not $NaoIniciar) {
    Start-Process explorer.exe "`"$exe`""
    Write-Host ''
    Write-Host 'Aplicativo aberto. Procure a bolinha colorida na bandeja do Windows (ao lado do relógio).'
}
Write-Host 'Pronto.'
