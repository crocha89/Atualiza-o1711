﻿<#
.SYNOPSIS
  Instala o Agente SIGA neste PC (um único aplicativo: bandeja + agente de telemetria e ficha + telas de situação e configuração).

.DESCRIPTION
  Rode em um PowerShell como Administrador, dentro da pasta do pacote:

      powershell -ExecutionPolicy Bypass -File .\Instalar.ps1

  Copia o aplicativo para Program Files, libera a pasta de dados, cria o atalho no Menu Iniciar, grava o endereço padrão do servidor
  (se informado), confere o XML do equipamento e abre o aplicativo. Na primeira abertura ele pergunta o que fazer (novo equipamento,
  código de pareamento ou só o agente) e liga sozinho o "iniciar com o Windows" (dá para desligar em Configurações).

  Para só testar, sem instalar: dê dois cliques em AgenteSiga.exe.

.PARAMETER Dir
  Pasta de destino. Padrão: C:\Program Files\Bionexo\AgenteSiga. Informando outra pasta, não exige Administrador.

.PARAMETER Servidor
  Endereço padrão do servidor do SIGA (http://... ou https://...). Fica em servidor-padrao.txt ao lado do aplicativo; quem instala
  não precisa digitar, e dá para trocar depois em Configurações (com senha). Sem este parâmetro, vale o que o pacote já trouxer.

.PARAMETER NaoIniciar
  Não abre o aplicativo ao final.
#>
param(
    [string]$Dir = (Join-Path $env:ProgramFiles 'Bionexo\AgenteSiga'),
    [string]$Servidor = '',
    [switch]$NaoIniciar
)
$ErrorActionPreference = 'Stop'

$origem  = $PSScriptRoot
$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $PSBoundParameters.ContainsKey('Dir') -and -not $ehAdmin) {
    throw 'Abra o PowerShell como Administrador (o destino padrão é o Program Files), ou use -Dir <pasta> para instalar em outro lugar.'
}
if (-not (Test-Path (Join-Path $origem 'AgenteSiga.exe'))) { throw 'AgenteSiga.exe não encontrado ao lado deste script.' }

Write-Host "Instalando o Agente SIGA em: $Dir"

# 1) encerra uma instância em execução (os dados já gravados ficam no banco)
Get-Process -Name AgenteSiga -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host '  encerrando a instância em execução...'
    Stop-Process -Id $_.Id -Force
    $_.WaitForExit(5000) | Out-Null
}

# 2) copia os arquivos
if ((Resolve-Path $origem).Path.TrimEnd('\') -ne ([IO.Path]::GetFullPath($Dir)).TrimEnd('\')) {
    New-Item -ItemType Directory -Force $Dir | Out-Null
    Get-ChildItem $origem -Force | Where-Object { $_.Name -notin 'Instalar.ps1', 'Desinstalar.ps1', 'LEIA-ME.txt' } |
        Copy-Item -Destination $Dir -Recurse -Force
}
$exe = Join-Path $Dir 'AgenteSiga.exe'
if (-not (Test-Path $exe)) { throw "Falha ao copiar: $exe não existe." }
Write-Host '  arquivos copiados.'

if ($Servidor) {
    $url = $Servidor.Trim().TrimEnd('/')
    if ($url -notmatch '^https?://') { throw 'O endereço do servidor deve começar com http:// ou https://.' }
    Set-Content -Path (Join-Path $Dir 'servidor-padrao.txt') -Value $url -Encoding ASCII
    Write-Host "  endereço padrão do servidor: $url"
}

# 3) pasta de dados (configuração, status e logs): o aplicativo roda com o usuário do Windows e precisa gravar nela
$dados = Join-Path $env:ProgramData 'Bionexo\AgenteSiga'
New-Item -ItemType Directory -Force $dados | Out-Null
if ($ehAdmin) { & icacls.exe $dados /grant '*S-1-5-32-545:(OI)(CI)M' /T /Q | Out-Null }
Write-Host "  dados em: $dados"

# 4) atalho no Menu Iniciar
$menu = if ($ehAdmin) { Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs' } else { Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs' }
$atalho = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $menu 'Agente SIGA.lnk'))
$atalho.TargetPath = $exe
$atalho.WorkingDirectory = $Dir
$atalho.Description = 'Agente SIGA - telemetria e ficha dos equipamentos'
$atalho.Save()
Write-Host '  atalho criado no Menu Iniciar.'

# 5) confere o XML do equipamento (só avisa; o aplicativo tenta de novo sozinho e a pasta pode ser trocada em Configurações)
Write-Host ''
Write-Host 'Conferindo o equipamento:'
# a pasta do Cabinet atual e a nova; a antiga (o Cabinet copia dela e a deixa no lugar) so vale se a nova nao tiver XML
$pasta = 'C:\Biotracker\Settings\App'
$xmls = @(Get-ChildItem $pasta -Filter *.xml -ErrorAction SilentlyContinue | Where-Object { (Get-Content $_.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -match '<CabinetSettings' })
if ($xmls.Count -eq 0) {
    $pasta = 'C:\Gtt Healthcare\GTCabinet Settings\App'
    $xmls = @(Get-ChildItem $pasta -Filter *.xml -ErrorAction SilentlyContinue | Where-Object { (Get-Content $_.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -match '<CabinetSettings' })
    if ($xmls.Count -gt 0) { Write-Host '  [!] so achei o XML na pasta antiga: abra o Cabinet uma vez para ele copiar para C:\Biotracker\Settings' }
}
if     ($xmls.Count -eq 1) { Write-Host "  [ok] configuração do equipamento: $($xmls[0].Name)" }
elseif ($xmls.Count -eq 0) { Write-Host "  [!] nenhum XML do equipamento (CabinetSettings) em $pasta - indique a pasta em Configurações" }
else                       { Write-Host "  [!] mais de um XML do equipamento em $pasta - o aplicativo não escolhe sozinho" }

# 6) abre o aplicativo pelo explorer.exe, que o inicia sem elevação, na sessão do usuário (a bandeja precisa disso)
if (-not $NaoIniciar) {
    Start-Process explorer.exe "`"$exe`""
    Write-Host ''
    Write-Host 'Aplicativo aberto. Na primeira vez ele pergunta o que fazer; depois, procure o ícone na bandeja do Windows (ao lado do relógio).'
}
Write-Host 'Pronto.'
