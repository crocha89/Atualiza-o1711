@echo off
rem Assistente de instalacao do equipamento (modelo, XML, Cabinet, Agente SIGA, Diagnostico e Equipment Status). Rode na area de trabalho do PC.
rem Pede permissao de administrador sozinho. Argumentos extras vao para o script (ex.: INSTALAR.bat -Simular).
setlocal
fltmc >nul 2>&1
if errorlevel 1 (
    echo Pedindo permissao de administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs"
    exit /b
)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-Equipamento.ps1" %*
echo.
pause
