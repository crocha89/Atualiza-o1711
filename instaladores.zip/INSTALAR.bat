@echo off
rem Instala o equipamento de uma vez (Cabinet, Hamachi, Agente SIGA e Equipment Status).
rem Pede permissao de administrador sozinho. Argumentos extras vao para o script (ex.: INSTALAR.bat -Simular).
setlocal
fltmc >nul 2>&1
if errorlevel 1 (
    echo Pedindo permissao de administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs"
    exit /b
)
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-Equipamento.ps1" %*
echo.
pause
