﻿<#
.SYNOPSIS
  Prepara um equipamento de uma vez: Cabinet (so copia), Agente SIGA e Equipment Status (o Hamachi e instalado a mao antes). PROVISORIO: serve ate o Cabinet enviar a
  telemetria sozinho; ai o Agente SIGA e desinstalado.

  O NOME DO PC E O HAMACHI NAO SAO FEITOS POR ESTE SCRIPT. O Hamachi guarda o nome do PC no momento da instalacao e o instalador dele precisa ser
  baixado pelo link toda vez, entao a ordem e: 1) acertar o nome do PC a mao, 2) instalar o Hamachi a mao pelo link e esperar ele conectar,
  3) rodar este script. Ele confere o nome (e pede confirmacao), o Hamachi (instalado, com IP 25.x) e o alcance do servidor, ANTES de mexer em qualquer coisa.

.DESCRIPTION
  Rode em um PowerShell como Administrador, dentro da pasta do pacote:

      INSTALAR.bat            (ou: powershell -ExecutionPolicy Bypass -File .\Instalar-Equipamento.ps1)

  Na pasta montada por montar-instalacao.ps1 nao precisa de parametro nenhum: ele acha o Cabinet, o Agente e o Equipment Status ao lado.

  Os passos, nesta ordem (a ordem importa):

   0. Confere o nome do PC, o Hamachi (instalado a mao, conectado) e o servidor. Nada e alterado ate aqui.
   1. Copia a pasta do release do Cabinet para C:\Biotracker\<pasta> (cria C:\Biotracker se preciso) e cria o atalho C:\GTCabinet.lnk.
   2. Abre o Cabinet UMA vez: ele copia a configuracao antiga (C:\Gtt Healthcare\GTCabinet Settings) para C:\Biotracker\Settings. O script espera o XML
      aparecer e fecha o Cabinet. NADA pode criar C:\Biotracker\Settings antes disso, senao a migracao nao roda.
   3. Instala o Agente SIGA e abre a tela de cadastro: o tecnico entra com o login do SIGA e escolhe o equipamento. O agente grava ativo, serie e local
      escolhidos no XML (com o Cabinet fechado).
   4. Ajusta o XML: a conexao do banco passa a apontar para .\instancia (o banco nao fica preso ao nome do PC) e, se pedido, ativo/serie/local.
   5. Instala o Equipment Status (/quiet). O servico abre o Cabinet pelo atalho C:\GTCabinet.lnk e fica vigiando.

  Ao terminar nao precisa reiniciar o PC: o servico do Equipment Status ja abriu o Cabinet.

  O Equipment Status vem DEPOIS do ajuste do XML de proposito: o Setup dele exige o XML ja em C:\Biotracker\Settings\App, cria a pasta Logs la dentro,
  e o servico reabre o Cabinet em segundos (que regravaria o XML).

.PARAMETER PastaCabinet
  Pasta do release do Cabinet (onde esta o Gtt.HealthTrack.Cabinet.exe). Sem ela, usa a unica pasta com esse arquivo ao lado deste script.
.PARAMETER PastaAgente
  Pasta do pacote do Agente SIGA (com o Instalar.ps1 e o AgenteSiga.exe). Padrao: Agente, ao lado deste script.
.PARAMETER EquipmentStatusSetup
  O EquipmentStatusSetup.exe. Padrao: EquipmentStatus\EquipmentStatusSetup.exe ao lado deste script.
.PARAMETER Servidor
  Endereco do servidor do SIGA. Padrao: http://25.11.4.148:8200 (o IP do servidor na rede do Hamachi). Vai para o Instalar.ps1 do agente, que o grava como o
  endereco padrao do pacote; da para trocar depois em Configuracoes do agente (com senha).
.PARAMETER Ativo, Serie, Local
  Se o tecnico nao escolher o equipamento na lista do agente, da para informar aqui o que vai no XML.
.PARAMETER SemPerguntar
  Nao pede a confirmacao do nome do PC (para uso sem ninguem na frente do teclado). O nome invalido continua barrando.
.PARAMETER SemHamachi
  Nao confere o Hamachi (para uma rede que nao seja a do Hamachi).
.PARAMETER SemAgente
  Pula o passo do agente.
.PARAMETER Simular
  So mostra o que faria, sem mudar nada.
#>
param(
    [string]$PastaCabinet = '',
    [string]$PastaAgente = (Join-Path $PSScriptRoot 'Agente'),
    [string]$EquipmentStatusSetup = (Join-Path $PSScriptRoot 'EquipmentStatus\EquipmentStatusSetup.exe'),
    [string]$Servidor = 'http://25.11.4.148:8200',
    [string]$Ativo = '',
    [string]$Serie = '',
    [string]$Local = '',
    [string]$Destino = 'C:\Biotracker',
    [switch]$SemHamachi,
    [switch]$SemAgente,
    [switch]$SemPerguntar,
    [switch]$Simular
)
$ErrorActionPreference = 'Stop'

# o que nao foi informado, procura ao lado deste script (a pasta de instalacao montada por montar-instalacao.ps1)
if (-not $PastaCabinet) {
    $achadas = @(Get-ChildItem $PSScriptRoot -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'Gtt.HealthTrack.Cabinet.exe') })
    if ($achadas.Count -eq 1) { $PastaCabinet = $achadas[0].FullName }
    elseif ($achadas.Count -eq 0) { throw 'Nao achei a pasta do Cabinet ao lado deste script (uma pasta com Gtt.HealthTrack.Cabinet.exe). Informe -PastaCabinet.' }
    else { throw ('Ha mais de uma pasta de Cabinet ao lado deste script: ' + (($achadas | ForEach-Object { $_.Name }) -join ', ') + '. Informe -PastaCabinet.') }
}

$CabinetExe     = 'Gtt.HealthTrack.Cabinet.exe'
$CabinetProc    = 'Gtt.HealthTrack.Cabinet'
$Atalho         = 'C:\GTCabinet.lnk'
$Settings       = Join-Path $Destino 'Settings'
$SettingsApp    = Join-Path $Settings 'App'
$AgenteDados    = Join-Path $env:ProgramData 'Bionexo\AgenteSiga'
$AgenteExe      = Join-Path $env:ProgramFiles 'Bionexo\AgenteSiga\AgenteSiga.exe'
$Servicos       = @('BionexoEquipmentStatus', 'EquipmentStatusWindowsService')
$resumo         = New-Object System.Collections.Generic.List[object]

function Passo($n, $titulo) { Write-Host ''; Write-Host "[$n] $titulo" -ForegroundColor Cyan }
function Ok($m)    { Write-Host "    ok: $m" -ForegroundColor Green }
function Aviso($m) { Write-Host "    ! $m" -ForegroundColor Yellow }
function Registra($passo, $estado, $nota) { $resumo.Add([pscustomobject]@{ Passo = $passo; Estado = $estado; Nota = $nota }) }
# em -Simular nada muda: so mostra
function Fazer($descricao, [scriptblock]$acao) {
    if ($Simular) { Write-Host "    [simular] $descricao" -ForegroundColor DarkGray; return $null }
    Write-Host "    $descricao"
    & $acao
}

function TemXmlDoCabinet($pasta) {
    if (-not (Test-Path $pasta)) { return $false }
    foreach ($f in Get-ChildItem $pasta -Filter *.xml -ErrorAction SilentlyContinue) {
        if ((Get-Content $f.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -match '<CabinetSettings') { return $true }
    }
    return $false
}

function FechaCabinet {
    $p = @(Get-Process -Name $CabinetProc -ErrorAction SilentlyContinue)
    if ($p.Count -eq 0) { return }
    foreach ($x in $p) { try { [void]$x.CloseMainWindow() } catch {} }
    Start-Sleep -Seconds 8
    Get-Process -Name $CabinetProc -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
}

function Espera($segundos, [scriptblock]$condicao) {
    $fim = (Get-Date).AddSeconds($segundos)
    while ((Get-Date) -lt $fim) { if (& $condicao) { return $true }; Start-Sleep -Seconds 3 }
    return $false
}

# ---------------------------------------------------------------- 0) conferencias
$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $ehAdmin -and -not $Simular) { throw 'Abra o PowerShell como Administrador.' }
$PastaCabinet = (Resolve-Path $PastaCabinet).Path
if (-not (Test-Path (Join-Path $PastaCabinet $CabinetExe))) { throw "$CabinetExe nao encontrado em $PastaCabinet." }
if (-not (Test-Path $EquipmentStatusSetup)) { throw "EquipmentStatusSetup.exe nao encontrado: $EquipmentStatusSetup" }
if (-not $SemAgente -and -not (Test-Path (Join-Path $PastaAgente 'Instalar.ps1'))) { throw "Instalar.ps1 do agente nao encontrado em $PastaAgente." }

# nome do PC: o Hamachi grava o nome do PC na instalacao, entao ele tem de estar certo ANTES (este script nao renomeia)
$nomePc = $env:COMPUTERNAME
Write-Host ''
Write-Host "Nome deste PC: $nomePc" -ForegroundColor White
if ($nomePc -notmatch '^[A-Za-z0-9-]{1,15}$' -or $nomePc -match '^\d+$') { throw "O nome do PC ('$nomePc') nao e valido para o padrao. Renomeie o PC a mao (ate 15 caracteres: letras, numeros e hifen; nao so numeros), reinicie e rode de novo." }
if ($nomePc -match '^(DESKTOP|WIN|LAPTOP|PC)-[A-Z0-9]{5,8}$') { Aviso 'esse parece o nome automatico do Windows, nao o ativo do PC.' }
if (-not $SemPerguntar -and -not $Simular) {
    if ((Read-Host 'Esse e o nome certo (ativo do PC)? O Hamachi vai usar ele. Continuar? (s/N)') -notmatch '^[sSyY]') { throw 'Cancelado: acerte o nome do PC, reinicie e rode de novo.' }
}

# Hamachi: instalado A MAO (pelo link de download), DEPOIS de acertar o nome do PC e ANTES deste script. Aqui so se confere.
if (-not $SemHamachi) {
    $svcHama = Get-Service -Name 'Hamachi2Svc' -ErrorAction SilentlyContinue
    $ipHama = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -like '25.*' })
    if (-not $svcHama) {
        $m = 'O Hamachi nao esta instalado neste PC. Instale pelo link de download (veja o LEIA-ME-INSTALACAO.txt), DEPOIS de acertar o nome do PC, e rode de novo.'
        if ($Simular) { Aviso $m } else { throw $m }
    }
    elseif ($ipHama.Count -eq 0) {
        $m = 'O Hamachi esta instalado mas sem IP 25.x: a rede ainda nao conectou. Espere o Hamachi ficar conectado (e confira que o PC entrou na rede do grupo) e rode de novo.'
        if ($Simular) { Aviso $m } else { throw $m }
    }
    else {
        Ok "Hamachi instalado e conectado (IP $($ipHama[0].IPAddress))."
        if ($Servidor -match '^https?://([^/:]+)(?::(\d+))?') {
            $hs = $Matches[1]; $porta = if ($Matches[2]) { [int]$Matches[2] } elseif ($Servidor -like 'https*') { 443 } else { 80 }
            $alcanca = (Test-NetConnection -ComputerName $hs -Port $porta -WarningAction SilentlyContinue).TcpTestSucceeded
            if ($alcanca) { Ok "alcancei o servidor ${hs}:$porta" } else { Aviso "nao alcancei o servidor ${hs}:${porta}: sem ele o cadastro no agente nao vai funcionar." }
        }
    }
}
if ($Simular) { Write-Host 'MODO SIMULAR: nada sera alterado.' -ForegroundColor Magenta }
else {
    New-Item -ItemType Directory -Force $AgenteDados | Out-Null
    try { Start-Transcript -Path (Join-Path $AgenteDados 'instalacao-equipamento.log') -Append | Out-Null } catch {}
}

# o servico antigo reabriria o Cabinet durante a copia e o ajuste do XML
foreach ($s in $Servicos) {
    if (Get-Service -Name $s -ErrorAction SilentlyContinue) { Fazer "parando o servico $s" { Stop-Service -Name $s -Force -ErrorAction SilentlyContinue } | Out-Null }
}
Fazer 'fechando o Cabinet, se estiver aberto' { FechaCabinet } | Out-Null

# ---------------------------------------------------------------- 1) copia o Cabinet e cria o atalho
Passo 1 "Cabinet: copiar para $Destino e criar o atalho $Atalho"
$destCabinet = Join-Path $Destino (Split-Path $PastaCabinet -Leaf)
$exeCabinet  = Join-Path $destCabinet $CabinetExe
if ((Split-Path $PastaCabinet -Parent).TrimEnd('\') -ieq $Destino.TrimEnd('\')) {
    Ok "o Cabinet ja esta em $PastaCabinet"
    $exeCabinet = Join-Path $PastaCabinet $CabinetExe
} else {
    Fazer "copiando $PastaCabinet para $destCabinet" {
        New-Item -ItemType Directory -Force $destCabinet | Out-Null     # cria C:\Biotracker se nao existir (NUNCA a pasta Settings)
        & robocopy.exe $PastaCabinet $destCabinet /E /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { throw "robocopy falhou (codigo $LASTEXITCODE)." }
    } | Out-Null
}
Fazer "criando o atalho $Atalho" {
    $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut($Atalho)
    $lnk.TargetPath = $exeCabinet
    $lnk.WorkingDirectory = Split-Path $exeCabinet -Parent
    $lnk.Save()
} | Out-Null
Registra 1 'ok' "Cabinet em $exeCabinet"

# ---------------------------------------------------------------- 2) primeira abertura do Cabinet (migra a configuracao)
Passo 2 'Cabinet: abrir uma vez para ele migrar a configuracao antiga'
if (TemXmlDoCabinet $SettingsApp) { Ok "a configuracao ja esta em $SettingsApp (nada a migrar)."; Registra 2 'ok' 'ja migrado' }
else {
    if (Test-Path $Settings) { throw "$Settings existe mas sem XML do Cabinet: a migracao automatica NAO roda assim. Apague ou renomeie essa pasta e rode de novo." }
    if (-not (TemXmlDoCabinet 'C:\Gtt Healthcare\GTCabinet Settings\App') -and -not $Simular) {
        throw 'Nao ha configuracao antiga (C:\Gtt Healthcare\GTCabinet Settings\App) para migrar. Copie a pasta do equipamento antes.'
    }
    Fazer 'abrindo o Cabinet e esperando o XML aparecer em C:\Biotracker\Settings\App (ate 3 min)' {
        Start-Process $exeCabinet -WorkingDirectory (Split-Path $exeCabinet -Parent) | Out-Null
        if (-not (Espera 180 { TemXmlDoCabinet $SettingsApp })) { FechaCabinet; throw 'O Cabinet nao criou o XML em 3 minutos.' }
        Start-Sleep -Seconds 10          # deixa terminar de copiar o resto
        FechaCabinet
    } | Out-Null
    Ok 'configuracao migrada; Cabinet fechado.'
    Registra 2 'ok' 'migrado'
}

# ---------------------------------------------------------------- 3) Agente SIGA (cadastro do equipamento)
Passo 3 'Agente SIGA: instalar e cadastrar o equipamento'
if ($SemAgente) { Aviso 'pulado (-SemAgente).'; Registra 3 'pulado' '' }
else {
    $instArgs = @{ NaoIniciar = $true }
    if ($Servidor) { $instArgs.Servidor = $Servidor }
    Fazer 'instalando o agente (Instalar.ps1)' { & (Join-Path $PastaAgente 'Instalar.ps1') @instArgs } | Out-Null
    $tokenJa = (Test-Path (Join-Path $AgenteDados 'agent.json')) -and ((Get-Content (Join-Path $AgenteDados 'agent.json') -Raw) -match '"TokenProtected"\s*:\s*"[^"]+')
    if ($tokenJa) { Ok 'este PC ja esta cadastrado no servidor.'; Registra 3 'ok' 'ja cadastrado' }
    else {
        Write-Host '    Na janela do agente: "Novo equipamento", entre com o login do SIGA e escolha o equipamento.' -ForegroundColor White
        Fazer 'abrindo o agente e esperando o cadastro (ate 20 min)' {
            Start-Process explorer.exe "`"$AgenteExe`""       # pelo explorer: abre sem elevacao, na sessao do usuario
            $feito = Espera 1200 { (Test-Path (Join-Path $AgenteDados 'agent.json')) -and ((Get-Content (Join-Path $AgenteDados 'agent.json') -Raw) -match '"TokenProtected"\s*:\s*"[^"]+') }
            if (-not $feito) { Aviso 'o cadastro nao foi concluido: o agente fica rodando sem parear (as leituras ficam no banco). Siga com o resto.' }
            else { Ok 'equipamento cadastrado.' }
        } | Out-Null
        Registra 3 'ok' ''
    }
}

# ---------------------------------------------------------------- 4) ajuste do XML (Cabinet fechado, Equipment Status ainda nao instalado)
Passo 4 'XML do Cabinet: conexao para .\instancia e identidade'
if (-not $SemAgente -and (Test-Path $AgenteExe)) {
    Fazer 'fechando o Cabinet, se algo o abriu' { FechaCabinet } | Out-Null
    $a = @('--aplicar-xml', '--normalizar-conexao')
    if ($Ativo) { $a += @('--ativo', "`"$Ativo`"") }
    if ($Serie) { $a += @('--serie', "`"$Serie`"") }
    if ($Local) { $a += @('--local', "`"$Local`"") }
    Fazer "AgenteSiga.exe $($a -join ' ')" {
        $p = Start-Process $AgenteExe -ArgumentList $a -Wait -PassThru
        $res = Join-Path $AgenteDados 'ultimo-resultado.txt'
        if (Test-Path $res) { Get-Content $res | ForEach-Object { Write-Host "    $_" } }
        switch ($p.ExitCode) {
            0 { Ok 'XML conferido.' }
            2 { Aviso 'XML ajustado com avisos (veja acima).' }
            4 { Aviso 'ha valores diferentes no XML; nao troquei. Rode com --sobrescrever se for o caso.' }
            3 { throw 'O Cabinet esta aberto: feche-o e rode de novo.' }
            default { throw "O ajuste do XML falhou (codigo $($p.ExitCode)). Veja $res." }
        }
    } | Out-Null
    Registra 4 'ok' ''
} else { Aviso 'sem o agente instalado o ajuste do XML foi pulado.'; Registra 4 'pulado' '' }

# ---------------------------------------------------------------- 5) Equipment Status
Passo 5 'Equipment Status'
if (-not (Test-Path $Atalho) -and -not $Simular) { throw "O atalho $Atalho nao existe." }
Fazer "rodando $EquipmentStatusSetup /quiet" {
    $p = Start-Process $EquipmentStatusSetup -ArgumentList '/quiet' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "O Setup do Equipment Status terminou com codigo $($p.ExitCode) (log em $Destino\Equipment Status\setup.log)." }
} | Out-Null
if (-not $Simular) {
    $svc = Get-Service -Name 'BionexoEquipmentStatus' -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running') { Ok 'servico em execucao.' } else { Aviso 'o servico BionexoEquipmentStatus nao esta em execucao.' }
    if (Espera 90 { [bool](Get-Process -Name $CabinetProc -ErrorAction SilentlyContinue) }) { Ok 'o servico abriu o Cabinet.' }
    else { Aviso 'o Cabinet nao abriu em 90 s (precisa de alguem logado no console).' }
}
Registra 5 'ok' ''

# ---------------------------------------------------------------- resumo
Write-Host ''
Write-Host 'Resumo:' -ForegroundColor Cyan
$resumo | Format-Table Passo, Estado, Nota -AutoSize | Out-String | Write-Host
if (-not $Simular) { try { Stop-Transcript | Out-Null } catch {} }
