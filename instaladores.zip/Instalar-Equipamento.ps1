﻿<#
.SYNOPSIS
  Instala o equipamento de uma vez: pergunta o modelo, ajusta o XML do Cabinet, copia o Cabinet, instala o Agente SIGA, o Diagnostico e o Equipment
  Status. PROVISORIO: serve ate o Cabinet enviar a telemetria sozinho; ai o Agente SIGA e desinstalado.

.DESCRIPTION
  Rode em um PowerShell COMO ADMINISTRADOR, na AREA DE TRABALHO do PC (pelo controle remoto ou presencial): o script abre o navegador, o Cabinet
  e a janela do agente. Dentro da pasta do pacote:

      INSTALAR.bat            (ou: powershell -ExecutionPolicy Bypass -File .\Instalar-Equipamento.ps1)

  Tudo que ele pergunta tambem existe como parametro (-Modelo, -Oncoprod, -Ativo, -Serie, -Local), para rodar sem perguntar (-SemPerguntar).

  Os passos, nesta ordem (a ordem importa):

   1. Nome do PC: confere (ate 15 caracteres; letras, numeros e hifen; nao so numeros) e pede confirmacao. O Hamachi guarda o nome do PC na instalacao,
      entao o nome certo vem ANTES e e feito a mao.
   2. Hamachi: confere o servico e o IP 25.x. Se nao estiver instalado, ABRE O NAVEGADOR no link de download (variavel $LinkHamachiPadrao, ou -LinkHamachi)
      e ESPERA ate 15 min o Hamachi conectar. Confere se o servidor responde.
   3. Perguntas: modelo (V4/V6, V5, Biocabinet, outro), cliente Oncoprod e, se quiser, ativo / nome / numero de serie do equipamento (em branco =
      deixa como esta no XML).
   4. Baixa o Diagnostico do repositorio (V5: Diagnostico 2.0; os demais: Diagnostico v7).
   5. Remove o Equipment Status antigo (os nomes de servico em $ServicosEquipmentStatus).
   6. Copia o Cabinet para C:\Biotracker\<pasta> e cria o atalho C:\GTCabinet.lnk.
   7. Configuracao: copia a pasta antiga (C:\Gtt Healthcare\GTCabinet Settings) para C:\Biotracker\Settings (o que o Cabinet faria na 1a abertura),
      ajusta o XML (modelo, http:// do endereco da Oncoprod, conexao .\instancia, identidade) e, na Oncoprod, o endpoint_connection no banco. Tudo com o
      Cabinet FECHADO e ANTES de ele abrir, entao ele ja sobe com a configuracao certa.
   8. Instala o Agente SIGA e abre o cadastro (o tecnico entra com o login do SIGA e escolhe o equipamento).
   9. Instala o Diagnostico baixado.
  10. Instala o Equipment Status (/quiet). O servico abre o Cabinet pelo atalho C:\GTCabinet.lnk e fica vigiando.

  O Equipment Status vem por ultimo de proposito: o Setup dele exige o XML ja em C:\Biotracker\Settings\App e o servico reabre o Cabinet em segundos.

.PARAMETER Modelo
  v4v6 | v5 | biocabinet | outro (outro = nao mexe no modelo do XML). Vazio = pergunta.
.PARAMETER Oncoprod
  sim | nao. Vazio = pergunta (sugere "sim" se o XML antigo ja aponta para oncoprod).
.PARAMETER Ativo, Serie, Local
  Ativo, numero de serie e nome do equipamento para o XML. Em branco = nao mexe (o XML fica como esta; o agente ainda pode preencher os vazios).
.PARAMETER LinkHamachi
  Link de download do Hamachi (troca o padrao do inicio do script).
.PARAMETER Repo, Ramo
  Repositorio do GitHub de onde vem o Diagnostico. Padrao: crocha89/Atualiza-o1711, ramo main.
.PARAMETER SemPerguntar
  Nao pergunta nada (usa os parametros; modelo e Oncoprod vem de -Modelo/-Oncoprod, ou ficam como estao).
.PARAMETER SemHamachi, SemAgente, SemDiagnostico
  Pulam o passo correspondente.
.PARAMETER Simular
  So mostra o que faria, sem mudar nada e sem perguntar.
#>
param(
    [string]$PastaCabinet = '',
    [string]$PastaAgente = (Join-Path $PSScriptRoot 'Agente'),
    [string]$EquipmentStatusSetup = (Join-Path $PSScriptRoot 'EquipmentStatus\EquipmentStatusSetup.exe'),
    [string]$Servidor = 'http://25.11.4.148:8200',
    [string]$Modelo = '',
    [string]$Oncoprod = '',
    [string]$Ativo = '',
    [string]$Serie = '',
    [string]$Local = '',
    [string]$Destino = 'C:\Biotracker',
    [string]$LinkHamachi = '',
    [string]$Repo = 'crocha89/Atualiza-o1711',
    [string]$Ramo = 'main',
    [switch]$SemHamachi,
    [switch]$SemAgente,
    [switch]$SemDiagnostico,
    [switch]$SemPerguntar,
    [switch]$Simular
)
$ErrorActionPreference = 'Stop'
$global:ProgressPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

# ======================= O QUE VOCE PODE ALTERAR AQUI =======================
# Link de download do Hamachi (abre no navegador so se o Hamachi nao estiver instalado). ATENCAO: se este script for para um repositorio PUBLICO,
# o link vai junto: prefira passar -LinkHamachi no comando.
$LinkHamachiPadrao = '{LINK_HAMACHI}'
# Nomes dos zips do Diagnostico no repositorio.
$ZipDiagnosticoV7 = 'Diagnostico v7.zip'
$ZipDiagnosticoV5 = 'Diagnosticov52-2.2.0.0.zip'
# Nomes do servico do Equipment Status (o equipamento so tem um, mas pode ser qualquer um destes). Procura pelo nome e pelo nome de exibicao.
$ServicosEquipmentStatus = @('BIONEXO.EQUIPMENT STATUS-SERVICE', 'BionexoEquipmentStatus', 'Gtt.EquipmentStatus-Service', 'Gtt.EquipmentStatus-Client')
# Endereco que a Oncoprod usa na tabela application_utils (chave endpoint_connection).
$EndpointOncoprod = 'ws-comercial-biotracker.bionexo.com'
# ============================================================================

$CabinetExe     = 'Gtt.HealthTrack.Cabinet.exe'
$CabinetProc    = 'Gtt.HealthTrack.Cabinet'
$Atalho         = 'C:\GTCabinet.lnk'
$Settings       = Join-Path $Destino 'Settings'
$SettingsApp    = Join-Path $Settings 'App'
$LegadoRaiz     = 'C:\Gtt Healthcare\GTCabinet Settings'
$LegadoApp      = Join-Path $LegadoRaiz 'App'
$AgenteDados    = Join-Path $env:ProgramData 'Bionexo\AgenteSiga'
$AgenteExe      = Join-Path $env:ProgramFiles 'Bionexo\AgenteSiga\AgenteSiga.exe'
$Cache          = Join-Path $AgenteDados 'cache'
$raw            = "https://raw.githubusercontent.com/$Repo/$Ramo"
$resumo         = New-Object System.Collections.Generic.List[object]

function Passo($n, $titulo) { Write-Host ''; Write-Host "[$n] $titulo" -ForegroundColor Cyan }
function Ok($m)    { Write-Host "    ok: $m" -ForegroundColor Green }
function Aviso($m) { Write-Host "    ! $m" -ForegroundColor Yellow }
function Registra($passo, $estado, $nota) { $resumo.Add([pscustomobject]@{ Passo = $passo; Estado = $estado; Nota = $nota }) }
# em -Simular nada muda: so mostra
function Fazer($descricao, [scriptblock]$acao) {
    if ($Simular) { Write-Host "    [simular] $descricao" -ForegroundColor DarkGray; return $null }
    Write-Host "    $descricao"
    & $acao
}

function TemXmlDoCabinet($pasta) {
    if (-not (Test-Path $pasta)) { return $false }
    foreach ($f in Get-ChildItem $pasta -Filter *.xml -ErrorAction SilentlyContinue) {
        if ((Get-Content $f.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -match '<CabinetSettings') { return $true }
    }
    return $false
}

# le do XML do Cabinet so o que o instalador mostra ou usa (nunca imprime a conexao: tem senha)
function LeXml($pasta) {
    if (-not (Test-Path $pasta)) { return $null }
    foreach ($f in Get-ChildItem $pasta -Filter *.xml -ErrorAction SilentlyContinue) {
        # (Get-Content ...) devolve UMA LINHA por item: junta antes de comparar, senao o -notmatch devolve as linhas que nao casam e pula o arquivo
        if (((Get-Content $f.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -join "`n") -notmatch '<CabinetSettings') { continue }
        try {
            $doc = New-Object System.Xml.XmlDocument
            $doc.Load($f.FullName)          # respeita o BOM e o encoding declarado no proprio XML
            $c = $doc.CabinetSettings
            return [pscustomobject]@{
                Caminho = $f.FullName; Ativo = [string]$c.AssetCode; Serie = [string]$c.SerialNumber; Local = [string]$c.LocationName
                Tipo = [string]$c.EquipmentType; Placa = [string]$c.HardwareSettings.HardwareType; Endpoint = [string]$c.ServicesEndPoint; Conexao = [string]$c.ConnectionString
            }
        } catch { return $null }
    }
    return $null
}

function FechaCabinet {
    $p = @(Get-Process -Name $CabinetProc -ErrorAction SilentlyContinue)
    if ($p.Count -eq 0) { return }
    foreach ($x in $p) { try { [void]$x.CloseMainWindow() } catch {} }
    Start-Sleep -Seconds 8
    Get-Process -Name $CabinetProc -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
}

function Espera($segundos, [scriptblock]$condicao) {
    $fim = (Get-Date).AddSeconds($segundos)
    while ((Get-Date) -lt $fim) { if (& $condicao) { return $true }; Start-Sleep -Seconds 3 }
    return $false
}

function SimNao($texto, [bool]$padraoSim) {
    $r = (Read-Host "$texto $(if ($padraoSim) { '(S/n)' } else { '(s/N)' })").Trim()
    if ($r -eq '') { return $padraoSim }
    return ($r -match '^[sSyY]')
}

function Pergunta($texto, $atual) {
    $dica = if ($atual) { "Enter = manter ""$atual""" } else { 'Enter = deixar como esta' }
    return (Read-Host "$texto [$dica]").Trim()
}

function EscolheModelo($atual) {
    Write-Host ''
    Write-Host 'Qual o modelo deste equipamento?' -ForegroundColor White
    if ($atual) { Write-Host "    (hoje o XML diz: $atual)" -ForegroundColor DarkGray }
    Write-Host '    1) V4 / V6   (Coldchain, IOBox e Full Gauge pela biblioteca)'
    Write-Host '    2) V5        (Coldchain V5, placa Elber-Icaru, so a porta 1)'
    Write-Host '    3) Biocabinet'
    Write-Host '    4) Outro / ja ajustado   (nao mexe no modelo do XML)'
    while ($true) {
        switch ((Read-Host 'Numero').Trim()) { '1' { return 'v4v6' } '2' { return 'v5' } '3' { return 'biocabinet' } '4' { return 'outro' } }
        Write-Host '    Digite 1, 2, 3 ou 4.' -ForegroundColor Yellow
    }
}

function BaixaRepo($nome, $saida) {
    $url = "$raw/$([uri]::EscapeDataString($nome))"
    for ($i = 1; $i -le 3; $i++) {
        try { Invoke-WebRequest -Uri $url -OutFile $saida -UseBasicParsing -TimeoutSec 900; if ((Get-Item $saida).Length -gt 0) { return }  }
        catch { Aviso "tentativa $i de baixar $nome falhou: $($_.Exception.Message)"; Start-Sleep -Seconds (5 * $i) }
    }
    throw "Nao consegui baixar $url"
}

# acha o servico do Equipment Status pelo nome OU pelo nome de exibicao (o equipamento tem so um, com nome variavel)
function ServicosAntigos {
    $achados = @()
    foreach ($n in $ServicosEquipmentStatus) {
        foreach ($s in @(Get-Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -ieq $n -or $_.DisplayName -ieq $n })) {
            if (-not ($achados | Where-Object { $_.Name -eq $s.Name })) { $achados += $s }
        }
    }
    return $achados
}

function RemoveServico($s) {
    $cim = Get-CimInstance Win32_Service -Filter "Name='$($s.Name)'" -ErrorAction SilentlyContinue
    $caminho = if ($cim) { $cim.PathName } else { '' }
    Write-Host "      servico $($s.Name) ($($s.DisplayName)) $caminho"
    try { Stop-Service -Name $s.Name -Force -ErrorAction SilentlyContinue } catch {}
    if ($caminho -match '^\s*"?([^"]+?\.exe)') {
        $proc = [IO.Path]::GetFileNameWithoutExtension($Matches[1])
        Get-Process -Name $proc -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    }
    & sc.exe delete $s.Name | Out-Null
    # o Windows so apaga o servico quando ninguem o segura: espera sumir antes do Setup criar o novo
    if (-not (Espera 45 { -not (Get-Service -Name $s.Name -ErrorAction SilentlyContinue) })) { Aviso "o servico $($s.Name) continua marcado para exclusao; reinicie o PC se o Setup do Equipment Status falhar." }
}

# ---------------------------------------------------------------- 0) conferencias
$ehAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $ehAdmin -and -not $Simular) { throw 'Abra o PowerShell como Administrador.' }
if ((Get-Process -Id $PID).SessionId -eq 0 -and -not $Simular) {
    throw 'Esta janela roda sem area de trabalho (sessao 0, como o PowerShell de fundo do LogMeIn). O instalador abre o navegador, o Cabinet e a janela do agente: rode pela tela do PC.'
}
if (-not $PastaCabinet) {
    $achadas = @(Get-ChildItem $PSScriptRoot -Directory | Where-Object { Test-Path (Join-Path $_.FullName $CabinetExe) })
    if ($achadas.Count -eq 1) { $PastaCabinet = $achadas[0].FullName }
    elseif ($achadas.Count -eq 0) { throw "Nao achei a pasta do Cabinet ao lado deste script (uma pasta com $CabinetExe). Rode o Baixar-e-Preparar.ps1 ou informe -PastaCabinet." }
    else { throw ('Ha mais de uma pasta de Cabinet ao lado deste script: ' + (($achadas | ForEach-Object { $_.Name }) -join ', ') + '. Informe -PastaCabinet.') }
}
$PastaCabinet = (Resolve-Path $PastaCabinet).Path
if (-not (Test-Path (Join-Path $PastaCabinet $CabinetExe))) { throw "$CabinetExe nao encontrado em $PastaCabinet." }
if (-not (Test-Path $EquipmentStatusSetup)) { throw "EquipmentStatusSetup.exe nao encontrado: $EquipmentStatusSetup" }
$AgentePacoteExe = Join-Path $PastaAgente 'AgenteSiga.exe'
if (-not (Test-Path (Join-Path $PastaAgente 'Instalar.ps1')) -or -not (Test-Path $AgentePacoteExe)) { throw "O pacote do agente (Instalar.ps1 e AgenteSiga.exe) nao esta em $PastaAgente." }
if ($Modelo -and @('v4v6', 'v5', 'biocabinet', 'outro') -notcontains $Modelo) { throw "-Modelo invalido: $Modelo (use v4v6, v5, biocabinet ou outro)." }
if ($Oncoprod -and @('sim', 'nao') -notcontains $Oncoprod) { throw "-Oncoprod invalido: $Oncoprod (use sim ou nao)." }

if ($Simular) { Write-Host 'MODO SIMULAR: nada sera alterado, nada sera perguntado.' -ForegroundColor Magenta }
else {
    New-Item -ItemType Directory -Force $AgenteDados | Out-Null
    try { Start-Transcript -Path (Join-Path $AgenteDados 'instalacao-equipamento.log') -Append | Out-Null } catch {}
}

# ---------------------------------------------------------------- 1) nome do PC
Passo 1 'Nome do PC'
$nomePc = $env:COMPUTERNAME
Write-Host "    Nome deste PC: $nomePc" -ForegroundColor White
if ($nomePc -notmatch '^[A-Za-z0-9-]{1,15}$' -or $nomePc -match '^\d+$') { throw "O nome do PC ('$nomePc') nao e valido para o padrao. Renomeie o PC a mao (ate 15 caracteres: letras, numeros e hifen; nao so numeros), reinicie e rode de novo." }
if ($nomePc -match '^(DESKTOP|WIN|LAPTOP|PC)-[A-Z0-9]{5,8}$') { Aviso 'esse parece o nome automatico do Windows, nao o ativo do PC.' }
if (-not $SemPerguntar -and -not $Simular) {
    if (-not (SimNao 'Esse e o nome certo (ativo do PC)? O Hamachi vai usar ele. Continuar?' $false)) { throw 'Cancelado: acerte o nome do PC, reinicie e rode de novo.' }
}
Registra 1 'ok' $nomePc

# ---------------------------------------------------------------- 2) Hamachi
Passo 2 'Hamachi'
if ($SemHamachi) { Aviso 'pulado (-SemHamachi).'; Registra 2 'pulado' '' }
else {
    $hamachiPronto = { [bool](Get-Service -Name 'Hamachi2Svc' -ErrorAction SilentlyContinue) -and @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -like '25.*' }).Count -gt 0 }
    if (-not (& $hamachiPronto)) {
        $link = if ($LinkHamachi) { $LinkHamachi } else { $LinkHamachiPadrao }
        $temSvc = [bool](Get-Service -Name 'Hamachi2Svc' -ErrorAction SilentlyContinue)
        Aviso $(if ($temSvc) { 'o Hamachi esta instalado mas sem IP 25.x: a rede ainda nao conectou.' } else { 'o Hamachi nao esta instalado neste PC.' })
        if ($Simular) { Aviso "[simular] abriria o navegador em: $link" }
        else {
            if ($link -notmatch '^https://') { throw 'Sem link do Hamachi: preencha $LinkHamachiPadrao no inicio do script ou use -LinkHamachi, instale o Hamachi a mao (depois do nome certo) e rode de novo.' }
            if (-not $temSvc) { Write-Host '    Abrindo o navegador no link de download. Baixe e instale o Hamachi (o nome do PC ja esta certo).'; Start-Process explorer.exe $link }
            Write-Host '    Esperando o Hamachi conectar (servico no ar e IP 25.x), ate 15 min...'
            if (-not (Espera 900 $hamachiPronto)) { throw 'O Hamachi nao conectou em 15 min. Confira a instalacao e se o PC entrou na rede do grupo; depois rode de novo.' }
        }
    }
    $ip = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -like '25.*' })
    if ($ip.Count -gt 0) {
        Ok "Hamachi conectado (IP $($ip[0].IPAddress))."
        if ($Servidor -match '^https?://([^/:]+)(?::(\d+))?') {
            $hs = $Matches[1]; $porta = if ($Matches[2]) { [int]$Matches[2] } elseif ($Servidor -like 'https*') { 443 } else { 80 }
            $alcanca = (Test-NetConnection -ComputerName $hs -Port $porta -WarningAction SilentlyContinue).TcpTestSucceeded
            if ($alcanca) { Ok "alcancei o servidor ${hs}:$porta" } else { Aviso "nao alcancei o servidor ${hs}:${porta}: sem ele o cadastro no agente nao vai funcionar." }
        }
    }
    Registra 2 'ok' ''
}

# ---------------------------------------------------------------- 3) perguntas
Passo 3 'Perguntas: modelo, cliente e identificacao do equipamento'
$xmlHoje = LeXml $SettingsApp
if (-not $xmlHoje) { $xmlHoje = LeXml $LegadoApp }
if (-not $xmlHoje -and -not $Simular) {
    # nao achou onde o Cabinet guarda a configuracao: mostra onde ha XML de Cabinet neste PC, para a pessoa ver o que aconteceu
    $achados = @()
    foreach ($raizBusca in 'C:\Gtt Healthcare', 'C:\Biotracker', 'C:\Cabinet', "$env:ProgramData\Bionexo") {
        if (Test-Path $raizBusca) { $achados += @(Get-ChildItem $raizBusca -Recurse -Filter *.xml -Depth 5 -ErrorAction SilentlyContinue | Where-Object { (Get-Content $_.FullName -TotalCount 5 -ErrorAction SilentlyContinue) -match '<CabinetSettings' } | ForEach-Object { $_.FullName }) }
    }
    $onde = if ($achados.Count) { "XML de Cabinet encontrado em: $($achados -join '; ')" } else { 'nenhum XML de Cabinet foi encontrado em C:\Gtt Healthcare, C:\Biotracker nem C:\Cabinet' }
    throw "Nao ha XML do Cabinet para configurar: falta $LegadoApp (copie a pasta do equipamento) ou ja migrado em $SettingsApp. $onde."
}
if ($xmlHoje) { Write-Host "    XML atual: EquipmentType=$($xmlHoje.Tipo)  HardwareType=$($xmlHoje.Placa)  ServicesEndPoint=$($xmlHoje.Endpoint)" -ForegroundColor DarkGray }

$perguntar = -not $SemPerguntar -and -not $Simular
if (-not $Modelo) { $Modelo = if ($perguntar) { EscolheModelo $xmlHoje.Tipo } else { 'outro' } }
if (-not $Oncoprod) {
    $palpite = [bool]($xmlHoje -and $xmlHoje.Endpoint -match 'oncoprod')
    $eOnco = if ($perguntar) { SimNao 'O cliente e a Oncoprod?' $palpite } else { $palpite }
}
else { $eOnco = ($Oncoprod -eq 'sim') }
if ($perguntar) {
    Write-Host '    Identificacao do equipamento no XML (opcional: em branco, fica como esta e voce pode preencher no proprio XML):' -ForegroundColor White
    if (-not $Ativo) { $Ativo = Pergunta '    Ativo do equipamento' $xmlHoje.Ativo }
    if (-not $Local) { $Local = Pergunta '    Nome do equipamento' $xmlHoje.Local }
    if (-not $Serie) { $Serie = Pergunta '    Numero de serie' $xmlHoje.Serie }
}
$nomeModelo = @{ v4v6 = 'V4 / V6'; v5 = 'V5'; biocabinet = 'Biocabinet'; outro = 'outro (nao mexe no modelo)' }[$Modelo]
Write-Host ''
Write-Host '    Vou fazer:' -ForegroundColor White
Write-Host "      modelo ........ $nomeModelo"
Write-Host "      Oncoprod ...... $(if ($eOnco) { "sim (http:// no ServicesEndPoint e endpoint_connection = $EndpointOncoprod no banco)" } else { 'nao' })"
Write-Host "      identificacao . ativo=$(if ($Ativo) { $Ativo } else { '(como esta)' })  nome=$(if ($Local) { $Local } else { '(como esta)' })  serie=$(if ($Serie) { $Serie } else { '(como esta)' })"
if ($perguntar -and -not (SimNao '    Continuar?' $true)) { throw 'Cancelado.' }
Registra 3 'ok' "$nomeModelo$(if ($eOnco) { ', Oncoprod' })"

# ---------------------------------------------------------------- 4) baixar o Diagnostico
Passo 4 'Diagnostico (baixar do repositorio)'
$diagZip = ''
if ($SemDiagnostico) { Aviso 'pulado (-SemDiagnostico).'; Registra 4 'pulado' '' }
else {
    $diagNome = if ($Modelo -eq 'v5') { $ZipDiagnosticoV5 } else { $ZipDiagnosticoV7 }
    if ($Simular) { Write-Host "    [simular] baixaria $raw/$diagNome" -ForegroundColor DarkGray; Registra 4 'simulado' $diagNome }
    else {
        try {
            New-Item -ItemType Directory -Force $Cache | Out-Null
            $diagZip = Join-Path $Cache $diagNome
            Write-Host "    baixando $diagNome ..."
            BaixaRepo $diagNome $diagZip
            Ok ('{0}: {1:N1} MB' -f $diagNome, ((Get-Item $diagZip).Length / 1MB))
            Registra 4 'ok' $diagNome
        }
        catch { Aviso "nao consegui baixar o Diagnostico ($($_.Exception.Message)). Sigo sem ele; instale depois."; $diagZip = ''; Registra 4 'aviso' 'nao baixou' }
    }
}

# ---------------------------------------------------------------- 5) Equipment Status antigo
Passo 5 'Equipment Status antigo: parar e remover'
$antigos = @(ServicosAntigos)
if ($antigos.Count -eq 0) { Ok 'nenhum servico antigo encontrado.'; Registra 5 'ok' 'nenhum' }
else {
    foreach ($s in $antigos) {
        if ($Simular) { Write-Host "    [simular] removeria o servico $($s.Name) ($($s.DisplayName))" -ForegroundColor DarkGray }
        else { RemoveServico $s }
    }
    Registra 5 'ok' (($antigos | ForEach-Object { $_.Name }) -join ', ')
}
Fazer 'fechando o Cabinet, se estiver aberto' { FechaCabinet } | Out-Null

# ---------------------------------------------------------------- 6) copia o Cabinet e cria o atalho
Passo 6 "Cabinet: copiar para $Destino e criar o atalho $Atalho"
$destCabinet = Join-Path $Destino (Split-Path $PastaCabinet -Leaf)
$exeCabinet  = Join-Path $destCabinet $CabinetExe
if ((Split-Path $PastaCabinet -Parent).TrimEnd('\') -ieq $Destino.TrimEnd('\')) {
    Ok "o Cabinet ja esta em $PastaCabinet"
    $exeCabinet = Join-Path $PastaCabinet $CabinetExe
} else {
    Fazer "copiando $PastaCabinet para $destCabinet" {
        New-Item -ItemType Directory -Force $destCabinet | Out-Null     # cria C:\Biotracker se nao existir (NUNCA a pasta Settings)
        & robocopy.exe $PastaCabinet $destCabinet /E /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { throw "robocopy falhou (codigo $LASTEXITCODE)." }
    } | Out-Null
}
Fazer "criando o atalho $Atalho" {
    $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut($Atalho)
    $lnk.TargetPath = $exeCabinet
    $lnk.WorkingDirectory = Split-Path $exeCabinet -Parent
    $lnk.Save()
} | Out-Null
Registra 6 'ok' "Cabinet em $exeCabinet"

# ---------------------------------------------------------------- 7) configuracao: copia a pasta antiga, ajusta o XML e o banco
Passo 7 'Configuracao: pasta antiga, XML e banco (Cabinet fechado, antes de ele abrir)'
# 7a) o mesmo que o Cabinet faria na 1a abertura (ApplicationPathHelper.MigrateLegacySettings): copia a arvore inteira para uma pasta de apoio e so
#     entao publica como C:\Biotracker\Settings, entao uma copia que falha nunca deixa configuracao pela metade.
if (TemXmlDoCabinet $SettingsApp) { Ok "a configuracao ja esta em $SettingsApp (nada a copiar)." }
else {
    if (Test-Path $Settings) { throw "$Settings existe mas sem XML do Cabinet: a copia NAO roda assim. Apague ou renomeie essa pasta e rode de novo." }
    if (-not (TemXmlDoCabinet $LegadoApp) -and -not $Simular) { throw "Nao ha configuracao antiga ($LegadoApp) para copiar. Copie a pasta do equipamento antes." }
    Fazer "copiando $LegadoRaiz para $Settings" {
        $apoio = "$Settings.migracao-$([guid]::NewGuid().ToString('N'))"
        & robocopy.exe $LegadoRaiz $apoio /E /NFL /NDL /NJH /NJS /NP | Out-Null
        if ($LASTEXITCODE -ge 8) { Remove-Item $apoio -Recurse -Force -ErrorAction SilentlyContinue; throw "robocopy falhou (codigo $LASTEXITCODE)." }
        Rename-Item -Path $apoio -NewName (Split-Path $Settings -Leaf)
        if (-not (TemXmlDoCabinet $SettingsApp)) { throw "A copia terminou mas nao ha XML do Cabinet em $SettingsApp." }
    } | Out-Null
    Ok 'configuracao copiada; a pasta antiga ficou como estava.'
}

# 7b) o XML (pelo executavel do agente, que ja sabe gravar com backup e sem desfazer o resto do arquivo)
$a = @('--aplicar-xml', '--normalizar-conexao', '--pasta', "`"$SettingsApp`"")
if (@('v4v6', 'v5', 'biocabinet') -contains $Modelo) { $a += @('--modelo', $Modelo) }
if ($eOnco) { $a += '--endpoint-http' }
if ($Ativo) { $a += @('--ativo', "`"$Ativo`"") }
if ($Serie) { $a += @('--serie', "`"$Serie`"") }
if ($Local) { $a += @('--local', "`"$Local`"") }
if ($Ativo -or $Serie -or $Local) { $a += '--sobrescrever' }          # o que foi digitado aqui vale sobre o que estava no XML
Fazer "AgenteSiga.exe $($a -join ' ')" {
    $p = Start-Process $AgentePacoteExe -ArgumentList $a -Wait -PassThru
    $res = Join-Path $AgenteDados 'ultimo-resultado.txt'
    if (Test-Path $res) { Get-Content $res | ForEach-Object { Write-Host "    $_" } }
    switch ($p.ExitCode) {
        0 { Ok 'XML conferido.' }
        2 { Aviso 'XML ajustado com avisos (veja acima).' }
        4 { Aviso 'ha valores diferentes no XML; nao troquei.' }
        3 { throw 'O Cabinet esta aberto: feche-o e rode de novo.' }
        default { throw "O ajuste do XML falhou (codigo $($p.ExitCode)). Veja $res." }
    }
} | Out-Null
Registra 7 'ok' 'XML'

# 7c) Oncoprod: o endereco do servidor tambem fica no banco (application_utils, chave endpoint_connection; a linha ja existe)
if ($eOnco) {
    if ($Simular) { Write-Host "    [simular] UPDATE application_utils SET ds_value = '$EndpointOncoprod' WHERE ds_key = 'endpoint_connection'" -ForegroundColor DarkGray }
    else {
        try {
            $sql = Get-Service -Name 'MSSQL$*' -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($sql -and $sql.Status -ne 'Running') { Write-Host "    iniciando o servico $($sql.Name) ..."; Start-Service $sql.Name; Start-Sleep -Seconds 5 }
            $conexao = (LeXml $SettingsApp).Conexao
            if (-not $conexao) { throw 'o XML nao tem ConnectionString.' }
            $cn = New-Object System.Data.SqlClient.SqlConnection $conexao
            try {
                $cn.Open()
                $c1 = $cn.CreateCommand(); $c1.CommandText = "SELECT ds_value FROM dbo.application_utils WHERE ds_key = N'endpoint_connection'"
                $antes = $c1.ExecuteScalar()
                if ($null -eq $antes) { Aviso 'a linha endpoint_connection nao existe na tabela application_utils; nao inseri nada.' }
                elseif ([string]$antes -eq $EndpointOncoprod) { Ok "endpoint_connection ja era $EndpointOncoprod." }
                else {
                    $c2 = $cn.CreateCommand(); $c2.CommandText = "UPDATE dbo.application_utils SET ds_value = @v WHERE ds_key = N'endpoint_connection'"
                    [void]$c2.Parameters.AddWithValue('@v', $EndpointOncoprod); [void]$c2.ExecuteNonQuery()
                    Ok "endpoint_connection: de '$antes' para '$EndpointOncoprod'."
                }
            } finally { $cn.Dispose() }
            Registra 7 'ok' 'banco (Oncoprod)'
        }
        catch { Aviso "nao consegui ajustar o endpoint_connection no banco: $($_.Exception.Message). Faca a mao: UPDATE application_utils SET ds_value='$EndpointOncoprod' WHERE ds_key='endpoint_connection'."; Registra 7 'aviso' 'banco nao ajustado' }
    }
}

# ---------------------------------------------------------------- 8) Agente SIGA (cadastro do equipamento)
Passo 8 'Agente SIGA: instalar e cadastrar o equipamento'
if ($SemAgente) { Aviso 'pulado (-SemAgente).'; Registra 8 'pulado' '' }
else {
    $instArgs = @{ NaoIniciar = $true }
    if ($Servidor) { $instArgs.Servidor = $Servidor }
    Fazer 'instalando o agente (Instalar.ps1)' { & (Join-Path $PastaAgente 'Instalar.ps1') @instArgs } | Out-Null
    $tokenJa = (Test-Path (Join-Path $AgenteDados 'agent.json')) -and ((Get-Content (Join-Path $AgenteDados 'agent.json') -Raw) -match '"TokenProtected"\s*:\s*"[^"]+')
    if ($tokenJa) { Ok 'este PC ja esta cadastrado no servidor.'; Registra 8 'ok' 'ja cadastrado' }
    else {
        Write-Host '    Na janela do agente: "Novo equipamento", entre com o login do SIGA e escolha o equipamento.' -ForegroundColor White
        Fazer 'abrindo o agente e esperando o cadastro (ate 20 min)' {
            Start-Process explorer.exe "`"$AgenteExe`""       # pelo explorer: abre sem elevacao, na sessao do usuario
            $feito = Espera 1200 { (Test-Path (Join-Path $AgenteDados 'agent.json')) -and ((Get-Content (Join-Path $AgenteDados 'agent.json') -Raw) -match '"TokenProtected"\s*:\s*"[^"]+') }
            if (-not $feito) { Aviso 'o cadastro nao foi concluido: o agente fica rodando sem parear (as leituras ficam no banco). Siga com o resto.' }
            else { Ok 'equipamento cadastrado.' }
        } | Out-Null
        Registra 8 'ok' ''
    }
}

# ---------------------------------------------------------------- 9) Diagnostico
Passo 9 'Diagnostico: instalar'
if ($SemDiagnostico -or ($Simular -and -not $diagZip)) {
    if ($Simular -and -not $SemDiagnostico) { Write-Host "    [simular] $(if ($Modelo -eq 'v5') { 'extrairia e rodaria o Instalar.ps1 do Diagnostico 2.0' } else { 'copiaria o Diagnostico v7 para C:\Biotracker e criaria o atalho na area de trabalho' })" -ForegroundColor DarkGray }
    Registra 9 $(if ($Simular -and -not $SemDiagnostico) { 'simulado' } else { 'pulado' }) ''
}
elseif (-not $diagZip -or -not (Test-Path $diagZip)) { Aviso 'o Diagnostico nao foi baixado: instale depois.'; Registra 9 'aviso' 'nao instalado' }
else {
    try {
        $pasta = Join-Path $Cache 'diagnostico'
        if (Test-Path $pasta) { Remove-Item $pasta -Recurse -Force }
        Expand-Archive -Path $diagZip -DestinationPath $pasta -Force
        $raiz = @(Get-ChildItem $pasta -Directory)
        $conteudo = if ($raiz.Count -eq 1 -and -not (Get-ChildItem $pasta -File)) { $raiz[0].FullName } else { $pasta }
        if ($Modelo -eq 'v5') {
            Write-Host '    Diagnostico 2.0 (V5): rodando o Instalar.ps1 dele.'
            & (Join-Path $conteudo 'Instalar.ps1') -NaoIniciar
            Registra 9 'ok' 'Diagnostico 2.0'
        } else {
            $destDiag = Join-Path $Destino 'Diagnostico v7'
            New-Item -ItemType Directory -Force $destDiag | Out-Null
            & robocopy.exe $conteudo $destDiag /E /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) { throw "robocopy falhou (codigo $LASTEXITCODE)." }
            $exe = Get-ChildItem $destDiag -Filter *.exe | Select-Object -First 1
            if ($exe) {
                $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'Diagnostico v7.lnk'))
                $lnk.TargetPath = $exe.FullName; $lnk.WorkingDirectory = $destDiag; $lnk.Save()
            }
            Ok "Diagnostico v7 em $destDiag (atalho na area de trabalho)."
            Registra 9 'ok' 'Diagnostico v7'
        }
    }
    catch { Aviso "nao consegui instalar o Diagnostico: $($_.Exception.Message)"; Registra 9 'aviso' 'falhou' }
}

# ---------------------------------------------------------------- 10) Equipment Status novo
Passo 10 'Equipment Status'
if (-not (Test-Path $Atalho) -and -not $Simular) { throw "O atalho $Atalho nao existe." }
Fazer "rodando $EquipmentStatusSetup /quiet" {
    $p = Start-Process $EquipmentStatusSetup -ArgumentList '/quiet' -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "O Setup do Equipment Status terminou com codigo $($p.ExitCode) (log em $Destino\Equipment Status\setup.log)." }
} | Out-Null
if (-not $Simular) {
    $svc = Get-Service -Name 'BionexoEquipmentStatus' -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running') { Ok 'servico em execucao.' } else { Aviso 'o servico BionexoEquipmentStatus nao esta em execucao.' }
    if (Espera 90 { [bool](Get-Process -Name $CabinetProc -ErrorAction SilentlyContinue) }) { Ok 'o servico abriu o Cabinet.' }
    else { Aviso 'o Cabinet nao abriu em 90 s (precisa de alguem logado no console).' }
}
Registra 10 'ok' ''

# ---------------------------------------------------------------- resumo
Write-Host ''
Write-Host 'Resumo:' -ForegroundColor Cyan
$resumo | Format-Table Passo, Estado, Nota -AutoSize | Out-String | Write-Host
if (-not $Simular) { try { Stop-Transcript | Out-Null } catch {} }
